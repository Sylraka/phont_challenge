
export const NavComponent = () => {

    return(
        <>
        <ul className="navUl">
            <li> Basics</li>
            <li>Transcription</li>
            <li> Translation</li>
            <li>Speaker</li>
            <li>Phonetics</li>
            <li>Emotion</li>
            <li>Noise</li>
            <li>Music</li>
            <li>Voice</li>
            <li>Accessiblity</li>
        </ul>
        </>
    )
}