export const InputComponent = () => {
return (
    <>
    <div className="input-container"></div>
    </>
)
}