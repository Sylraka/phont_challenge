import './App.css';
import React from 'react'


import {TimelinePage} from "./pages/TimelinePage";

const App = () => {
  return (
    <>
      <div className="App">
      <TimelinePage/>
      </div>
    </>
  );
}

export default App;
